<!-- open terminal and press "npm i" to install all dependencies -->

<!-- press in the terminal "npm run devStart" and enter -->

<!-- once it says "server is running on port 3000", go to your browser and type "Localhost:3000" to load home page -->

<!-- you must sign up and log in to access the other features of the site. e.g your dashboard, your upload page and posting -->

<!-- Any new php, html, js and css file you create must be in the "public" folder unless it won't work -->


<!-- DO NOT TOUCH ANYTHING IN UPLOAD.JS. IT IS THE SERVER AND ROUTER abeg, e hard me to code -->

<!-- DO NOT CHANGE FILE LOCATIONS!!! -->